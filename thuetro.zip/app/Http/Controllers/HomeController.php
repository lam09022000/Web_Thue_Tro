<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session ;
use DB ;
use Illuminate\Support\Facades\Redirect ;
session_start() ;

class HomeController extends Controller
{
    public function check_acc(){
        $check_acc = Session::get('user_id') ;
        if($check_acc){}
        else{
            return Redirect::to('/user/login') ;
        }
    }
    public function index(){
        $all_post = DB::table('tbl_post')->where('post_status','1')->orderBy('post_id','desc')->limit('6')->get() ;
        $all_post_by_like = DB::table('tbl_post')->where('post_status','1')->orderBy('post_like','desc')->limit('6')->get() ;
        $all_area = DB::table('tbl_area')->orderBy('area_name','desc')->get() ;
        return view('pages.home')->with('all_post',$all_post)->with('all_area',$all_area)->with('all_post_by_like',$all_post_by_like) ;
    }
    public function group_post_by_name($area_name){
        $id = DB::table('tbl_area')->where('area_name',$area_name)->first() ;
        $all_post = DB::table('tbl_post')->where('post_status','1')->where('area_name',$area_name)->orderBy('post_id','desc')->limit('6')->get() ;
        $all_area = DB::table('tbl_area')->orderBy('area_name','desc')->get() ;
        return view('group_post')->with('all_post',$all_post)->with('all_area',$all_area) ;
    }
    public function group_post_by_type($group_type){
        if($group_type == 1 ){
            $all_post = DB::table('tbl_post')->where('post_status','1')->orderBy('post_like','desc')->limit('6')->get() ;
        }else{
            $all_post = DB::table('tbl_post')->where('post_status','1')->orderBy('post_id','desc')->limit('6')->get() ;
        }
        $all_area = DB::table('tbl_area')->orderBy('area_name','desc')->get() ;
        return view('group_post')->with('all_post',$all_post)->with('all_area',$all_area) ;
    }
    public function infor(){
        
         return view('information') ;
    }
    public function apartment($post_id){
        $post = DB::table('tbl_post')->where('post_id',$post_id)->first() ;
        $post_same = DB::table('tbl_post')->where('post_id','<>',$post->post_id)->where('area_name',$post->area_name)->limit('6')->get() ;
        $cmt= DB::table('comment')->where('post_id',$post->post_id)->limit('6')->get() ;
        $user= DB::table('tbl_user')->where('user_name',$post->user_name)->first() ;
        return view('apartment_rental')->with('post',$post)->with('post_same',$post_same)->with('all_cmt',$cmt)->with('user',$user);
   }
   public function comment(Request $request ,$post_id){
    $check_acc = Session::get('user_id') ;
        if($check_acc){}
        else{
            return Redirect::to('/user/login') ;
        }
    $data['post_id'] = $post_id ;
    $data['user_name'] = Session::get('user_name') ; 
    $data['content'] = $request->cmt_content ;
    DB::table('comment')->insert($data) ;
    return Redirect::to('apartment/'.$post_id) ;
}
}
