<?php

namespace App\Http\Controllers;
use Session ;
use Illuminate\Http\Request;
use DB ;
use Illuminate\Support\Facades\Redirect ;

class AdminController extends Controller
{
    public function index(){ 
        $count_post = DB::table('tbl_post')->count() ;
        $count_acc = DB::table('tbl_user')->count() ;
        return view('pages.content_admin')->with('count_acc',$count_acc)->with('count_post',$count_post) ;
    }
    public function login(){
        return view('admin_login') ;
    }
    public function registration(){
        return view('admin_registration') ;
    }
    public function wait_post()
    {
        return view('pages.wait_post') ;
    }
    public function add_post()
    {
        return view('pages.add_post') ;
    }
    public function acc_owner(){ 
        $count_acc = DB::table('tbl_user')->where('user_type','1')->get() ;
        return view('pages.v_ac_owner')->with('all_ac',$count_acc) ;
    }
    public function acc_tt(){ 
        $count_acc = DB::table('tbl_user')->where('user_type','0')->get() ;
        return view('pages.v_ac_owner')->with('all_ac',$count_acc) ;
    }
    public function check_login(Request $request){
        $admin_email = $request->admin_email ;
        $admin_password = $request->admin_password ;
        $result = DB::table('tbl_admin')->where('admin_email',$admin_email)->where('admin_password',md5($admin_password))->first() ;
        if($result){
            Session::put('admin_name',$result->admin_name);
            Session::put('admin_id',$result->admin_id);
            return Redirect::to('/admin') ;

        }else{
            Session::put('message','Tài Khoản hoặc mật khẩu không chính xác');
            return Redirect::to('/login') ;

        }
    }
    public function check_registration(Request $request){
        $data = array() ;
        $data['admin_email'] = $request->Email ;
        $data['admin_password'] = $request->Password ;
        $data['admin_phone'] = $request->Phone ;
        $data['admin_name'] = $request->Name ;
        //thêm vào cơ sở dữ liệu 
        DB::table('tbl_admin')->insert($data) ;
        Session::put('message','Đăng kí thành công') ;
        return Redirect::to('/login') ;
    }
}
