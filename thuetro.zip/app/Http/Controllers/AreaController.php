<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session ;
use DB ;
use Illuminate\Support\Facades\Redirect ;
session_start() ;
class AreaController extends Controller

{
    public function add_area()
    {
        return view('pages.add_area') ;
    }
    public function save_area(Request $request){
        $data = array() ;
        $data['area_name'] = $request->area_name ;
        $data['area_desc'] = $request->area_desc ;
        $data['area_status'] = 1 ;
        DB::table('tbl_area')->insert($data) ;
        Session::put('message','Thêm phân loại thành công');
        return Redirect::to('admin/all-area') ;

    }
    public function all_area(Request $request){
        $all_area = DB::table('tbl_area')->get() ;
        $area =  view('pages.all_area')->with('all_area',$all_area) ;
        return  view('admin_layout')->with('pages.all_area',$area) ;

    }
    public function edit_area($area_id){
        $edit_area = DB::table('tbl_area')->Where('area_id',$area_id)->get() ;
        $area =  view('pages.edit_area')->with('edit_area',$edit_area) ;
        return  view('admin_layout')->with('pages.edit_area',$area) ;


    }
    public function update_area(Request $request , $area_id){
        $data = array() ;
        $data['area_name'] = $request->area_name ;
        $data['area_desc'] = $request->area_desc ;
        $data['area_status'] = 1 ;
        DB::table('tbl_area')->where('area_id',$area_id)->update($data) ;
        Session::put('message','Chỉnh sửa thành công');
        return Redirect::to('admin/all-area') ;


    }
    public function delete_area($area_id){
        DB::table('tbl_area')->where('area_id',$area_id)->delete() ;
        Session::put('message','Xóa thành công');
        return Redirect::to('admin/all-area') ;

    }
}
