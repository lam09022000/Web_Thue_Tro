<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session ;
use DB ;
use Illuminate\Support\Facades\Redirect ;
session_start() ;
class CategoryRoom extends Controller

{
    public function add_category()
    {
        return view('pages.add_category') ;
    }
    public function save_category(Request $request){
        $data = array() ;
        $data['category_name'] = $request->category_name ;
        $data['category_desc'] = $request->category_desc ;
        $data['category_status'] = 1 ;
        DB::table('tbl_category_room')->insert($data) ;
        Session::put('message','Thêm phân loại thành công');
        return Redirect::to('admin/all-category-room') ;

    }
    public function all_category(Request $request){
        $all_category_room = DB::table('tbl_category_room')->get() ;
        $category_room =  view('pages.all_category_room')->with('all_category_room',$all_category_room) ;
        return  view('admin_layout')->with('pages.all_category_room',$category_room) ;

    }
    public function edit_category($category_id){
        $edit_category_room = DB::table('tbl_category_room')->Where('category_id',$category_id)->get() ;
        $category_room =  view('pages.edit_category')->with('edit_category',$edit_category_room) ;
        return  view('admin_layout')->with('pages.edit_category',$category_room) ;


    }
    public function update_category(Request $request , $category_id){
        $data = array() ;
        $data['category_name'] = $request->category_name ;
        $data['category_desc'] = $request->category_desc ;
        $data['category_status'] = 1 ;
        DB::table('tbl_category_room')->where('category_id',$category_id)->update($data) ;
        Session::put('message','Chỉnh sửa thành công');
        return Redirect::to('admin/all-category-room') ;


    }
    public function delete_category($category_id){
        DB::table('tbl_category_room')->where('category_id',$category_id)->delete() ;
        Session::put('message','Xóa thành công');
        return Redirect::to('admin/all-category-room') ;

    }
}
