<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session ;
use DB ;
use Illuminate\Support\Facades\Redirect ;
session_start() ;


class PostController extends Controller
{
    public function add_post()
    {
        return view('pages.post.add_post') ;
    }
    public function save_post(Request $request){
        $data = array() ;
        $data['post_title'] = $request->post_name ;
        $data['post_content'] = $request->post_desc ;
        $data['post_status'] = 1 ;
        DB::table('tbl_post')->insert($data) ;
        Session::put('message','Thêm phân loại thành công');
        return Redirect::to('admin/all-post') ;

    }
    public function all_post(Request $request){
        $all_post = DB::table('tbl_post')->get() ;
        $post =  view('pages.post.all_post')->with('all_post',$all_post) ;
        return  view('admin_layout')->with('pages.post.all_post',$post) ;

    }
    public function wait_post(Request $request){
        $wait_post = DB::table('tbl_post')->where('post_status','0')->get() ;
        $post =  view('pages.post.wait_post')->with('wait_post',$wait_post) ;
        return  view('admin_layout')->with('pages.post.wait_post',$post) ;

    }
    public function my_post(Request $request , $user_id){
        $all_post = DB::table('tbl_post')->Where('user_id',$user_id)->get() ;
        $post =  view('pages.post.my_post')->with('my_post',$all_post) ;
        return  view('admin_layout')->with('pages.post.my_post',$post) ;

    }
    public function edit_post($post_id){
        $edit_post = DB::table('tbl_post')->Where('post_id',$post_id)->get() ;
        $post =  view('pages.post.edit_post')->with('edit_post',$edit_post) ;
        return  view('admin_layout')->with('owner.edit_post',$post) ;


    }
    public function update_post(Request $request , $post_id){
        $data = array() ;
        $data['post_name'] = $request->post_name ;
        $data['post_desc'] = $request->post_desc ;
        $data['post_status'] = 1 ;
        DB::table('tbl_post')->where('post_id',$post_id)->update($data) ;
        Session::put('message','Chỉnh sửa thành công');
        return Redirect::to('admin/all-post') ;


    }
    public function delete_post($post_id){
        DB::table('tbl_post')->where('post_id',$post_id)->delete() ;
        Session::put('message','Xóa thành công');
        return Redirect::to('admin/all-post') ;

    }
    public function allow_post($post_id){
        $data['post_status'] = 1 ;
        DB::table('tbl_post')->where('post_id',$post_id)->update($data) ;
        Session::put('message','phê duyệt bài viết thành công');
        return Redirect::to('admin/wait-post') ;

    }
}
