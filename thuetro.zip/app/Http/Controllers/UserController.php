<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session ;
use DB ;
use Illuminate\Support\Facades\Redirect ;
session_start() ;

class UserController extends Controller
{
    //lấy trang quản lý của owner
    public function index($user_id){
        return view('owner.owner_layout') ;
    }
    //lấy thông tin của người dùng
    public function infor($user_id){
        $result = DB::table('tbl_user')->where('user_id',$user_id)->first() ;
        Session::put('user_name',$result->user_name);
        Session::put('user_id',$result->user_id);
        Session::put('user_type',$result->user_type);
        Session::put('user_email',$result->user_email);
        Session::put('user_phone',$result->user_phone);
        Session::put('user_add',$result->user_add);
        Session::put('user_number_cmnd',$result->user_number_CMND);
        return view('information') ;
    }
    public function layout(){
        return view('owner.owner_layout') ;
    }
    //lấy trang đăng nhâp 
    public function acc_login(){
        Session::put('user_name',null);
        Session::put('user_id',null);
        Session::put('user_type',null);
       return view('User.user_login') ;
    }
    // đăng xuất 
    public function acc_logout(){
            Session::put('user_name',null);
            Session::put('user_id',null);
            Session::put('user_type',null);

        return view('owner.owner_layout') ;
    }
    // đăng kí tài khoản
    public function acc_registration(){
        return view('user.user_registration') ;
    }
    //kiểm tra đăng nhập
    public function check_login(Request $request){
        $user_email = $request->user_email ;
        $user_password = $request->user_password ;
        $result = DB::table('tbl_user')->where('user_email',$user_email)->where('user_password',md5($user_password))->first() ;
        if($result){
            Session::put('user_name',$result->user_name);
            Session::put('user_id',$result->user_id);
            Session::put('user_type',$result->user_type);
            return Redirect::to('/')->with('nameuser',$request->user_name) ;

        }else{
            Session::put('message','Tài Khoản hoặc mật khẩu không chính xác');
            return Redirect::to('user/login') ;

        }
    }
    // kiểm tra đăng kí
    public function check_registration(Request $request){
        $data = array() ;
        $data['user_email'] = $request->Email ;
        $data['user_password'] = md5($request->Password) ;
        $data['user_phone'] = $request->Phone ;
        $data['user_name'] = $request->Name ;
        //thêm vào cơ sở dữ liệu 
        DB::table('tbl_user')->insert($data) ;
        Session::put('message','Đăng kí thành viên thành công') ;
        return Redirect::to('user/login') ;
    }
    public function owner_registration($user_id){
        $data['user_type'] = 1 ;
        DB::table('tbl_user')->where('user_id',$user_id)->update($data) ;
        return  view('owner.owner_layout');
    }




    // OwerController
    public function add_post()
    {
        $area = DB::table('tbl_area')->get() ;
        $category = DB::table('tbl_category_room')->get() ;
        return view('owner.add_post')->with('area',$area)->with('category',$category) ;
    }
    public function save_post(Request $request  ){
        $data = array() ;
        $data['post_title'] = $request->post_title ;
        $data['post_content'] = $request->post_content ;
        $data['post_status'] = 0 ;
        $data['user_name'] = Session::get('user_name') ;
        $category_name = DB::table('tbl_category_room')->where('category_name',$request->post_category)->first() ;
        $data['category_name'] = $request->post_category;
        $area_name = DB::table('tbl_area')->where('area_name',$request->post_area)->first() ;
        $data['area_name'] = $request->post_area ;
        $data['post_address'] = $request->post_address ;
        $data['price'] = $request->price ;
        $data['post_s'] = $request->post_s;
        $data['picture'] = $request->image1 ;
        $data['picture1'] = $request->image2 ;
        $data['picture2'] = $request->image3 ;
        DB::table('tbl_post')->insert($data);
        Session::put('message','Thêm danh mục thành công');
        
        return Redirect::to('user/my-post') ;


        

    }
    public function all_post(Request $request){
        $all_post = DB::table('tbl_post')->get() ;
        $post =  view('owner.all_post')->with('all_post',$all_post) ;
        return  view('owner.owner_layout')->with('owner.all_post',$post) ;

    }
    public function wait_post(){
        $id= Session::get('user_name') ;
        $wait_post = DB::table('tbl_post')->where('user_name',$id)->where('post_status','0')->get() ;
        $post =  view('owner.wait_post')->with('wait_post',$wait_post) ;
        return  view('owner.owner_layout')->with('owner.wait_post',$post) ;

    }
    public function my_post(){
        $name= Session::get('user_name') ;
        $my_post = DB::table('tbl_post')->Where('user_name',$name)->get() ;
        $post =  view('owner.my_post')->with('my_post',$my_post) ;
        return  view('owner.owner_layout')->with('owner.my_post',$post) ;

    }
    public function edit_post($post_id){
        $edit_post = DB::table('tbl_post')->Where('post_id',$post_id)->get() ;
        $area = DB::table('tbl_area')->get() ;
        $category = DB::table('tbl_category_room')->get() ;
        $post =  view('owner.edit_post')->with('edit_post',$edit_post)->with('area',$area)->with('category',$category)  ;
        
        return  view('owner.owner_layout')->with('owner.edit_post',$post);


    }
    public function update_post(Request $request , $post_id){
        $data = array() ;
        $data['post_title'] = $request->post_title ;
        $data['post_content'] = $request->post_content ;
        $data['post_status'] = 0 ;
        $data['user_name'] = Session::get('user_name') ;
        $category_name = DB::table('tbl_category_room')->where('category_name',$request->post_category)->first() ;
        $data['category_name'] = $request->post_category;
        $area_name = DB::table('tbl_area')->where('area_name',$request->post_area)->first() ;
        $data['area_name'] = $request->post_area ;
        $data['post_address'] = $request->post_address ;
        $data['price'] = $request->price ;
        $data['picture'] = $request->image1 ;
        DB::table('tbl_post')->insert($data);
        Session::put('message','Chỉnh sửa danh mục thành công');
        
        return Redirect::to('user/my-post') ;


    }
    public function delete_post($post_id){
        DB::table('tbl_post')->where('post_id',$post_id)->delete() ;
        Session::put('message','Xóa thành công');
        return Redirect::to('user/all-post') ;

    }

    
}
