<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nhóm</title>
    <script src="{{asset('public/frontend/js/jquery-3.3.1.js')}}"></script>
    <script src="{{asset('public/frontend/js/bootstrap.min.js')}}"></script>
    <link rel="stylesheet" href="{{asset('public/frontend/css/bootstrap.min.css')}}">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/frontend/fonts/fontawesome/css/all.min.css')}}">
    <link href="https://fonts.googleapis.com/css2?family=Paytone+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/frontend/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/post.css')}}">

<body>
    <!-- header -->
    <header id="header">
        <!-- header top -->
        <div class="header__top">
            <div class="container">
                <section class="row flex">
                    <div class="col-lg-5 col-md-0 col-sm-0 heade__top-left">
                        <span>Nhà Trọ BaLaNha</span>
                    </div>

                    <nav class="col-lg-7 col-md-0 col-sm-0 header__top-right">
                        <ul class="header__top-list">
                            <li class="header__top-item">
                                <?php
                                        $name = Session::get('user_name');
                                        $id = Session::get('user_id');
                                        echo " <a href=\"http://localhost/thuetro/user/$id\" class=\"header__top-link\"> $name</a>  ";
                                    ?>
                            </li>

                            <li class="header__top-item">
                                
                                    <?php
                                        $type = Session::get('user_type') ;
                                        if($type == 1){
                                        echo " <a href=\"http://localhost/thuetro/user/manager/$id\" class=\"header__top-link\">Quản lý</a>  ";
                                        }else{
                                            if($type == null) echo "<a href=\"http://localhost/thuetro/user/registration\" class=\"header__top-link\">Đăng kí</a> " ;
                                            else

                                            echo " <a href=\"http://localhost/thuetro/user/registration-owner/$id\" class=\"header__top-link\">Đăng kí chủ trọ</a>  ";
                                        }
                                    ?>
                                </a>
                            </li>

                            <li class="header__top-item">
                                <a href="{{URL::to('user/login')}}" class="header__top-link">
                                    <?php
                                    $id = Session::get('user_id');
                                    if($id != null){
                                        echo "Đăng xuất" ;
                                    }
                                    else {
                                        echo "Đăng nhập" ;
                                    }

                                    ?>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </section>
            </div>
        </div>
        <!--end header top -->

        <!-- header bottom -->
        <div class="header__bottom">
            <div class="container">
                <section class="row">
                    <div class="col-lg-3 col-md-4 col-sm-12 header__logo">
                        <h1 class="header__heading">
                            <a href="index.html" class="header__logo-link">
                                <img src="../public/frontend/images/logo.png" alt="Logo" class="header__logo-img">
                            </a>
                        </h1>
                    </div>

                    <div class="col-lg-6 col-md-7 col-sm-0 header__search">

                        <input type="text" class="header__search-input" placeholder="Tìm kiếm tại đây...">
                        <button class="header__search-btn">
                            <div class="header__search-icon-wrap">
                                <i class="fas fa-search header__search-icon"></i>
                            </div>
                        </button>
                    </div>

                    <div class="col-lg-2 col-md-0 col-sm-0 header__call">
                    </div>
                </section>
            </div>
        </div>
        <!--end header bottom -->

        <!-- header nav -->
        <div class="header__nav">
            <div class="container">
                <section class="row">
                    <div class="header__nav-menu-wrap col-lg-3 col-md-0 col-sm-0">
                        <i class="fas fa-bars header__nav-menu-icon"></i>
                        <div class="header__nav-menu-title">Tìm theo khu vực</div>
                    </div>

                    <div class="header__nav col-lg-9 col-md-0 col-sm-0">
                        <ul class="header__nav-list">
                            <li class="header__nav-item">
                                <a href="{{URL::to('/trang-chu')}}" class="header__nav-link">Trang chủ</a>
                            </li>
                            <li class="header__nav-item">
                                <a href="{{URL::to('/group-post/2')}}" class="header__nav-link">Bài viết</a>
                            </li>
                            <li class="header__nav-item">
                                <a href="contact.html" class="header__nav-link">Liên hệ</a>
                            </li>
                        </ul>
                    </div>
                </section>
            </div>
        </div>
    </header>
    <!--end header nav -->

    <!-- posts -->
    <section class="posts">
        <div class="container">
            <div class="row pc">
                <nav class="menu__nav col-lg-3 col-md-12 col-sm-0">
                    <ul class="menu__list">
                        @foreach($all_area as $key => $area)
                            <li class="menu__item menu__item--active">
                                <a href="{{URL::to('/group-post/'.$area->area_name)}}" class="menu__link">
                                    {{$area->area_name}}</a>
                            </li>
                        @endforeach
                    </ul>
                </nav>

                <div class="breadcrumbs col-lg-12 col-md-12 col-sm-12">
                    Trang chủ &raquo <span class="breadcrumbs__active">Bài viết</span>
                </div>
            </div>

            <div class="row">
                <article class="post__list col-lg-9 col-md-9 col-sm-12">
                    @foreach($all_post as $key => $post)
                    <a href="{{URL::to('/apartment/'.$post->post_id)}}" >
                    <div class="post__item">
                        <div class="post__item-img-wrap">
                        <?php
                        echo "<img src=\"../public/frontend/images/post/$post->picture\" alt=\"Hình ảnh\" style=\"width:100%\" class=\"product__panel-img\">"
                        ?>
                        </div>
                        <div class="post__item-content">
                            <div class="post__item-title">
                                
                                    <h2 class="post__item-heading">
                                        {{$post->post_title}}
                                    </h2>
                                
                            </div>

                            <div class="posts__item-cate-wrap">
                                <div class="posts__item-cate">
                                    <i class="fa fa-folder posts__item-cate-icon"></i>
                                    <div class="posts__item-cate-name">
                                        {{$post->area_name}}
                                    </div>
                                </div>
                                <div class="posts__item-cate-ad">
                                    <i class="fa fa-user posts__item-cate-ad-icon"></i>
                                    <div class="posts__item-cate-ad-name">
                                        {{$post->user_name}}
                                    </div>
                                </div>
                            </div>
                            <div class="posts__item-description">
                                {{$post->post_content}} </div>
                        </div>
                    </div>
                    </a>
                    @endforeach


                    <nav class="post__pagination">
                        <ul class="post__pagination-list">
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#" aria-label="Previous">
                                    <span class="post__pagination-link-prev">&laquo;</span>
                                </a>
                            </li>
                            <li class="post__pagination-item post__pagination-item--active">
                                <a class="post__pagination-link" href="#">1</a>
                            </li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#">2</a>
                            </li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#">3</a>
                            </li>
                            <li class="post__pagination-item post__pagination-item--center">...</li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#">9</a>
                            </li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#">10</a>
                            </li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#">11</a>
                            </li>
                            <li class="post__pagination-item">
                                <a class="post__pagination-link" href="#" aria-label="Next">
                                    <span class="post__pagination-link-next">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </article>

                <aside class="post__aside col-lg-3 col-md-3 col-sm-0">
                    <div class="post__aside-top">
                        <div class="post__aside-title">
                            <h3 class="post__aside-heading">
                                Bài viết liên quan
                            </h3>

                            <div class="post__aside-list">
                                <div class="post__aside-item post__aside-item--no-border">
                                    <div class="post__aside-img-wrap">
                                        <img src="../public/frontend//images/expert1.jpg" class="post__aside-img">
                                    </div>
                                    <div class="post__aside-title">
                                        <a href="#" class="post__aside-link">
                                            <h4 class="post__aside-link-heading">Kinh nghiệm sống tại hà nội</h4>
                                        </a>
                                    </div>
                                </div>

                                <div class="post__aside-item post__aside-item--no-border">
                                    <div class="post__aside-img-wrap">
                                        <img src="../public/frontend/images/product_1.png" class="post__aside-img">
                                    </div>
                                    <div class="post__aside-title">
                                        <a href="#" class="post__aside-link">
                                            <h4 class="post__aside-link-heading">Kinh nghiệm thuê trọ
                                            </h4>
                                        </a>
                                    </div>
                                </div>

                                <div class="post__aside-item post__aside-item--no-border">
                                    <div class="post__aside-img-wrap">
                                        <img src="../public/frontend/images/banner_4.jpg" class="post__aside-img">
                                    </div>
                                    <div class="post__aside-title">
                                        <a href="#" class="post__aside-link">
                                            <h4 class="post__aside-link-heading">Nhà giá rẻ</h4>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- <div class="post__aside-bottom">
                        <h3 class="post__aside-heading">
                            Có thể bạn thích
                        </h3>

                        <div class="post__aside-list">
                            <div class="post__aside-item post__aside-item--border">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_1.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Mũ bảo hiểm fullface
                                        Yoyal QC201</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            990.000
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_10.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Mũ bảo hiểm fullface
                                        Yoyal 2020</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            1.490.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_3.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Mũ bảo hiểm LS2 đẹp
                                        chính hãng</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            1.200.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_7.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Mũ bảo hiểm mới nhất
                                        2020</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            1.200.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_4.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Mũ bảo hiểm LS2 chất
                                        lượng, bền</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            2.220.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_6.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Áo Khoác Nam dành 
                                        cho người đi phượt khac ca tinh viet nam</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            1.120.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_5.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Găng tay leo núi cho
                                        mới nhất 2020</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            200.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="post__aside-item">
                                <div class="post__aside-img-wrap">
                                    <img src="images/product_12.png" class="post__aside-img">
                                </div>
                                <div class="post__aside-title">
                                    <a href="#" class="post__aside-link">
                                        <h4 class="post__aside-link-heading">Quần phượt cho Nam</h4>
                                    </a>

                                    <div class="post__aside-rate-wrap">
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                        <i class="fas fa-star post__aside-rate"></i>
                                    </div>

                                    <div class="post__aside-price">
                                        <span class="post__aside-price-current">
                                            500.000đ
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </aside>
            </div>
        </div>
    </section>
    <!--end posts -->

    <!-- footer -->
    <footer>
        <section class="footer__top">
            <div class="container">
                <div class="row">
                    <article class="footer__top-intro col-lg-5 col-md-4 col-sm-6">
                        <h4 class="footer__top-intro-heading">
                            Về chúng tôi
                        </h4>
                        <div class="footer__top-intro-content">
                            Nhatrobalnha trụ sở tại xuanthuy-caugiay<br>
                            Chúng tôi sẽ liên tục cập nhật những ngôi nhà<br>
                            mới nhất, chất lượng nhất, hợp thời<br>
                            nhất giúp các bạn có những trải nghiệm <br>
                            tuyệt vời! <br> <br>
                            Điện thoại: 0368494*** <br>
                            Email: lus187@gmail.com <br>
                            Zalo: 036 8494 *** <br>
                        </div>
                    </article>

                    <article class="footer__top-policy col-lg-3 col-md-4 col-sm-6">
                        <h4 class="footer__top-policy-heading">
                            HỖ TRỢ KHÁCH HÀNG
                        </h4>

                        <ul class="footer__top-policy-list">
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Trung tâm trợ giúp</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">An toàn mua bán</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Quy định cần biết</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Quy chế quyền riếng tư</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Liên hệ hỗ trợ</a>
                            </li>
                        </ul>
                    </article>

                    <article class="footer__top-contact-wrap col-lg-4 col-md-4 col-sm-6">
                        <h4 class="footer__top-contact-heading">
                            Hotline liên hệ
                        </h4>

                        <div class="footer__top-contact">
                            <div class="footer__top-contact-icon">
                                <img src="images/phone_top.png" class="footer__top-contact-img">
                            </div>

                            <div class="footer__top-contact-phone-wrap">
                                <div class="footer__top-contact-phone">
                                    0368494***
                                </div>
                                <div class="footer__top-contact-des">
                                    (Tư vấn miễn phí 24/24)
                                </div>
                            </div>
                        </div>

                        <h4 class="footer__top-contact-heading">
                            Kết nối với chúng tôi
                        </h4>

                        <div class="footer__top-contact-social">
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="images/facebook.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="images/youtube.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="images/tiktok.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="images/zalo.png">
                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
        <section class="footer__bottom">
            <div class="container">
                <div class="row">
                    <span class="footer__bottom-content">@Bản quyền thuộc về nhatrobalanha</span>
                </div>
            </div>
        </section>
    </footer>
    <!-- end footer -->
    <script src="{{asset('public/frontend/js/jq.js')}}"></script>
</body>

</html>