@extends('admin_layout')
@section('content_admin')
<section class="wrapper">
    <div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Thêm Bài Viết
                    </header>
                    <div class="panel-body">
                        <div class="position-center">
                            <form role="form" action="{{URL::to('admin/save-post')}}" method="post">
                                {{csrf_field()}}
                                <div class="form-group">
                                    Tiêu đề<input type="text" class="form-control" id="" name="post_title"
                                        placeholder="Tên tiêu đề">
                                </div>
                                <div class="form-group">
                                    Miêu Tả<input type="text" class="form-control" id="" name="post_content"
                                        placeholder="Mô Tả về Loại Phòng">
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <select class="form-control m-bot15">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                        </select>

                                        <select multiple="" class="form-control">
                                            <option>1</option>
                                            <option>2</option>
                                            <option>3</option>
                                            <option>4</option>
                                            <option>5</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    Địa chỉ chính xác<input type="text" class="form-control" id="" name="post_address"
                                        placeholder="Địa chỉ">
                                </div>

                                <label class="col-sm-3 control-label col-lg-3" for="inputSuccess">Tiện ích</label>
                                <div class="col-lg-6">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Phòng tắm
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Phòng bếp
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Wifi
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            TV
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Tủ lạnh
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Bình Nóng lạnh
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Điều hòa
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Nơi để xe
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" value="">
                                            Thời gian tự do
                                        </label>
                                    </div>

                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="optionsRadios" id="optionsRadios1" value="option1"
                                                checked="">
                                            Chung chủ
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="optionsRadios" id="optionsRadios2"
                                                value="option2">
                                            Không chung chủ
                                    </div>

                                </div>
                                <button type="submit" class="btn btn-info">Thêm </button>
                            </form>
                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
@endsection