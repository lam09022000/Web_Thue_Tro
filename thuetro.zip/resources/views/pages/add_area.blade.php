@extends('admin_layout')
@section('content_admin')
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="panel">
                        <header class="panel-heading">
                           Thêm Khu Vực
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="{{URL::to('admin/save-area')}}" method="post">
                                {{csrf_field()}}
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="area_name" placeholder="Tên Khu Vực">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="area_desc" placeholder="Mô Tả về Khu Vực">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-info">Thêm </button>
                            </form>
                            </div>

                        </div>
                    </section>
            </div>
        </div>
    </div>
</section>
@endsection