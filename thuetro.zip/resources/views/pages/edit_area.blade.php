@extends('admin_layout')
@section('content_admin')
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="panel">
                        <header class="panel-heading">
                           Chỉnh sửa Khu Vực
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                            @foreach($edit_area as $key => $edit_pro)
                                <form role="form" action="{{URL::to('admin/update-area/'.$edit_pro->area_id)}}" method="post">
                                {{csrf_field()  }}
                                <div class="form-group">
                                    <input type="text" class="form-control" value="{{ $edit_pro->area_name}}" id="" name="area_name" placeholder="Tên Khu Vực">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" rows="8" value="{{ $edit_pro->area_desc}}" id="" name="area_desc" placeholder="Mô Tả về Khu Vực">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-info">Sửa</button>
                            </form>
                            @endforeach
                            </div>

                        </div>
                    </section>
            </div>
        </div>
    </div>
</section>
@endsection