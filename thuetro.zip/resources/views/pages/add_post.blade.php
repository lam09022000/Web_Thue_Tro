@extends('admin_layout')
@section('content_admin')
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="panel">
                        <header class="panel-heading">
                           Thêm Loại Phòng
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                                <form role="form" action="{{URL::to('admin/add-category')}}" method="post">
                                {{csrf_field()  }}
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="category_name" placeholder="Tên Loại phòng">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="category_desc" placeholder="Mô Tả về phòng">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-info">Thêm </button>
                            </form>
                            </div>

                        </div>
                    </section>
            </div>
        </div>
    </div>
</section>
@endsection