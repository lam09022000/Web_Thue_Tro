<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BTL</title>
    <script src="{{asset('public/frontend/js/jquery-3.3.1.js')}}"></script>
    <script src="{{asset('public/frontend/js/bootstrap.min.js')}}"></script>
    <link rel="stylesheet" href="{{asset('public/frontend/css/bootstrap.min.css')}}">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/frontend/fonts/fontawesome/css/all.min.css')}}">
    <link href="https://fonts.googleapis.com/css2?family=Paytone+One&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('public/frontend/css/style.css')}}">
    <link rel="stylesheet" href="{{asset('public/frontend/css/home.css')}}">
</head>

<body>
    <div class="app">
        <header id="header">
            <!-- header top -->
            <div class="header__top">
                <div class="container">
                    <section class="row flex">
                        <div class="col-lg-5 col-md-0 col-sm-0 heade__top-left">
                            <span>Nhà Trọ BaLaNha</span>
                        </div>

                        <nav class="col-lg-7 col-md-0 col-sm-0 header__top-right">
                            <ul class="header__top-list">
                                <li class="header__top-item">
                                    <?php
                                        $name = Session::get('user_name');
                                        $id = Session::get('user_id');
                                        echo " <a href=\"http://localhost/thuetro/user/$id\" class=\"header__top-link\"> $name</a>  ";
                                    ?>
                                </li>

                                <li class="header__top-item">
                                    <a href="{{URL::to('/user/manage')}}" class="header__top-link">
                                    <?php
                                        $type = Session::get('user_type') ;
                                        if($type == 1){
                                        echo " <a href=\"http://localhost/thuetro/user/manager/$id\" class=\"header__top-link\">Quản lý</a>  ";
                                        }else{
                                            if($type == 0) echo "<a href=\"http://localhost/thuetro/user/registration-owner/$id\" class=\"header__top-link\">Đăng kí chủ trọ</a>  " ;
                                            else

                                            echo " <a href=\"http://localhost/thuetro/user/registration\" class=\"header__top-link\">Đăng kí</a> ";
                                        }
                                    ?>
                                </a>
                                </li>

                                <li class="header__top-item">
                                    <a href="{{URL::to('user/login')}}" class="header__top-link">
                                    <?php
                                    $id = Session::get('user_id');
                                    if($id != null){
                                        echo "Đăng xuất" ;
                                    }
                                    else {
                                        echo "Đăng nhập" ;
                                    }

                                    ?>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </section>
                </div>
            </div>
            <!--end header top -->

            <!-- header bottom -->
            <div class="header__bottom">
                <div class="container">7
                    <section class="row">
                        <div class="col-lg-3 col-md-4 col-sm-12 header__logo">
                            <h1 class="header__heading">
                                <a href="#" class="header__logo-link">
                                    <img src="./images/logo.png" alt="Logo" class="header__logo-img">
                                </a>
                            </h1>
                        </div>

                        <div class="col-lg-6 col-md-7 col-sm-0 header__search">
                            <!--<select name="" id="" class="header__search-select">
                            <option value="0">All</option>
                            <option value="1">Mũ bảo hiểm</option>
                            <option value="2">Găng tay</option>
                            <option value="3">Áo phượt</option>
                            <option value="4">Giày phượt</option>
                            <option value="5">Balo phượt</option>
                        </select>  -->
                            <input type="text" class="header__search-input" autocomplete="address-level1" placeholder="Tìm kiếm tại đây...">
                            <button class="header__search-btn">
                                <div class="header__search-icon-wrap">
                                    <i class="fas fa-search header__search-icon"></i>
                                </div>
                            </button>
                        </div>

                        <div class="col-lg-2 col-md-0 col-sm-0 header__call">
                            <div class="header__call-icon-wrap">
                                <i class="fas fa-phone-alt header__call-icon"></i>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
            <!--end header bottom -->

            <!-- header nav -->
            <div class="header__nav">
                <div class="container">
                    <section class="row">
                        <div class="header__nav-menu-wrap col-lg-3 col-md-0 col-sm-0">
                            <i class="fas fa-bars header__nav-menu-icon"></i>
                            <div class="header__nav-menu-title">Tìm theo Khu vực</div>
                        </div>

                        <div class="header__nav col-lg-9 col-md-0 col-sm-0">
                            <ul class="header__nav-list">
                                <li class="header__nav-item">
                                    <a href="{{URL::to('/')}}" class="header__nav-link">Trang chủ</a>
                                </li>
                                <li class="header__nav-item">
                                    <a href="{{URL::to('/group-post/2')}}" class="header__nav-link">Bài viết </a>
                                </li>
                                <li class="header__nav-item">
                                    <a href="contact.html" class="header__nav-link">Liên hệ</a>
                                </li>
                            </ul>
                        </div>
                    </section>
                </div>
            </div>
        </header>
        <!--end header nav -->

        <!-- slide - menu list -->
        <section class="menu-slide">
            <div class="container">
                <div class="row">
                    <nav class="menu__nav col-lg-3 col-md-12 col-sm-0">
                        <ul class="menu__list">
                        @foreach($all_area as $key => $area)
                            <li class="menu__item menu__item--active">
                                <a href="{{URL::to('/group-post/'.$area->area_name)}}" class="menu__link">
                                    {{$area->area_name}}</a>
                            </li>
                        @endforeach
                        </ul>
                    </nav>

                    <div class="slider col-lg-9 col-md-12 col-sm-0">
                        <div class="row">
                            <div class="slide__left col-lg-8 col-md-0 col-sm-0">
                                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel"
                                    data-interval="3000">
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img src="./images/banner_1.jpg" class="d-block w-100" alt="...">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="./images/banner_8.jpg" class="d-block w-100" alt="...">
                                        </div>
                                        <div class="carousel-item">
                                            <img src="./images/banner_9.jpg" class="d-block w-100" alt="...">
                                        </div>
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button"
                                        data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button"
                                        data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                                <div class="slide__left-bottom">
                                    <div class="slide__left-botom-one">
                                        <img src="./images/banner_3.jpg" class="slide__left-bottom-one-img">
                                    </div>
                                    <div class="slide__left-bottom-two">
                                        <img src="./images/banner_4.jpg" class="slide__left-bottom-tow-img">
                                    </div>
                                </div>
                            </div>

                            <div class="slide__right col-lg-4 col-md-0 col-sm-0">
                                <img src="./images/Untitled-1.JPG" class="slide__right-img">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end slide menu list -->

    <!-- lấy dữ liệu bài viết -->
    <section class="bestselling">
        <div class="container">
            <div class="row">
                <div class="bestselling__heading-wrap">
                    <!-- <img src="images/bestselling.png" alt="Sản phẩm bán chạy"
                    class="bestselling__heading-img"> -->
                    <div class="bestselling__heading">ReView </div>
                </div>
            </div>

            <!-- <section class="row">
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_1.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Mũ bảo hiểm fullfaceYoyal QC201</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            900.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_8.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Mũ bảo hiểm fullfaceYoyal 2020</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            1.490.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_3.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Mũ bảo hiểm LS2 đẹp chính hãng</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            1.200.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_4.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Mũ bảo hiểm LS2 chất lượng, bền</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            2.220.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_5.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Găng tay leo núi mới nhất 2020</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            200.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
                <div class="bestselling__product col-lg-4 col-md-6 col-sm-12">
                    <div class="bestselling__product-img-box">
                        <img src="images/product_6.png" alt="Mũ bảo hiểm" class="bestselling__product-img">
                    </div>
                    <div class="bestselling__product-text">
                        <h3 class="bestselling__product-title">
                            <a href="#" class="bestselling__product-link">Áo Khoác Nam dành cho người đi phượt Áo đi phượt cho Nam mới ới 2020 đẹp bắt mắt Áo đi phư</a>
                        </h3>

                        <div class="bestselling__product-rate-wrap">
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                            <i class="fas fa-star bestselling__product-rate"></i>
                        </div>

                        <span class="bestselling__product-price">
                            1.120.000đ
                        </span>

                        <div class="bestselling__product-btn-wrap">
                            <button class="bestselling__product-btn">Xem hàng</button>
                        </div>
                    </div>
                </div>
            </section> -->

            <div class="row bestselling__banner">

                <div class="bestselling__banner-left col-lg-6">
                    <img src="./images/hanoi.jpg " alt="Banner quảng cáo"
                    class="bestselling__banner-left-img">
                
                </div>
                <div class="bestselling__banner-right col-lg-6">
                    <img src="./images/saigon.jpg" alt="Banner quảng cáo"
                    class="bestselling__banner-right-img">
                </div>
            </div>
        </div>
    </section>
    <!-- kết thúc lấy dữ liệu bài viết -->
    <!-- product love -->
    <section class="product__love">
        <div class="container">
            <div class="row bg-white">
                <div class="col-lg-12 col-md-12 col-sm-12 product__love-title">
                    <h2 class="product__love-heading">
                       Phòng đề xuất 
                    </h2>
                </div>
            </div>
            <div class="row bg-white">
            @foreach($all_post as $key => $post)
                <div class="product__panel-item col-lg-2 col-md-3 col-sm-6">
                    <div class="product__panel-img-wrap">
                        <?php
                        echo "<img src=\"./public/frontend/images/post/$post->picture\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
                    </div>
                    <h3 class="product__panel-heading">
                        <a href="{{URL::to('/apartment/'.$post->post_id)}}" class="product__panel-link">{{ $post->post_title }}</a>
                    </h3>
                    <div>
                        
                    </div>

                    <div class="product__panel-price">
                        <span class="product__panel-price-old product__panel-price-old-hide">
                        {{ $post->price }}
                        </span>
                        <span class="product__panel-price-current">
                        {{ $post->price }} $
                        </span>
                    </div>
                </div>
            @endforeach
            </div>

            <article class="row posts__view">
                <a href="{{URL::to('/group-post/1')}}" class="posts__view-btn">Xem thêm</a>
            </article>

        </div>
    </section>
    <!--end product love -->
    <!--phòng được đề xuất -->
    <section class="product__love">
        <div class="container">
            <div class="row bg-white">
                <div class="col-lg-12 col-md-12 col-sm-12 product__love-title">
                    <h2 class="product__love-heading">
                       Phòng được quan tâm nhiều
                    </h2>
                </div>
            </div>
            <div class="row bg-white">
            @foreach($all_post_by_like as $key => $post)
                <div class="product__panel-item col-lg-2 col-md-3 col-sm-6">
                    <div class="product__panel-img-wrap">
                    <?php
                        echo "<img src=\"./public/frontend/images/post/$post->picture\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
                    </div>
                    <h3 class="product__panel-heading">
                        <a href="{{URL::to('/apartment')}}" class="product__panel-link">{{$post->post_title}}</a>
                    </h3>
                    <div class="product__panel-rate-wrap">
                        <i class="fas fa-star product__panel-rate"></i>
                        <i class="fas fa-star product__panel-rate"></i>
                        <i class="fas fa-star product__panel-rate"></i>
                        <i class="fas fa-star product__panel-rate"></i>
                        <i class="fas fa-star product__panel-rate"></i>
                    </div>

                    <div class="product__panel-price">
                        <span class="product__panel-price-old product__panel-price-old-hide">
                        {{$post->post_title}}
                        </span>
                        <span class="product__panel-price-current">
                        {{$post->price}}
                        </span>
                    </div>
                </div>
                @endforeach
            </div>

            <article class="row posts__view">
                <a href="{{URL::to('/group-post/2')}}" class="posts__view-btn">Xem thêm</a>
            </article>

        </div>
    </section>
    <!--kết thúc đề xuất-->

    <!-- post -->
    <!-- post -->
    <section class="posts">
        <div class="container">
            <header class="row posts__title">
                <div class="posts__title-wrap col-lg-12 col-md-12 col-sm-12">
                    <h2 class="posts__heading">
                        Tin tức 
                    </h2>
                </div>
            </header>
            <article class="row posts__list">
                <div class="posts__item col-lg-3 col-md-6 col-sm-6">
                    <div class="posts__item-img">
                        <img src="./images/product_1.png">
                    </div>
                    <h3 class="posts__item-heading">
                        <a href="" class="posts__item-title">
                           chung cư pearl
                        </a>
                    </h3>
                    <div class="posts__item-date">
                       25m^2
                    </div>
                    <div class="posts__item-cate-wrap">
                        <div class="posts__item-cate">
                            <i class="fa fa-folder posts__item-cate-icon"></i>
                            <div class="posts__item-cate-name">
                                Tin tức
                            </div>
                        </div>
                        <div class="posts__item-cate-ad">
                            <i class="fa fa-user posts__item-cate-ad-icon"></i>
                            <div class="posts__item-cate-ad-name">
                                Xuân Lâm
                            </div>   
                        </div>
                    </div>
                    <div class="posts__item-description">
                        Nhà tại đường
                        quận........
                        huyện........
                    </div>
                </div>

                <div class="posts__item col-lg-3 col-md-6 col-sm-6">
                    <div class="posts__item-img">
                        <img src="./images/expert1.jpg">
                    </div>
                    <h3 class="posts__item-heading">
                        <a href="" class="posts__item-title">
                            chyung cư đô thị nam thăng long<br>
                            .....
                        </a>
                    </h3>
                    <div class="posts__item-date">
                       100m^2
                    </div>
                    <div class="posts__item-cate-wrap">
                        <div class="posts__item-cate">
                            <i class="fa fa-folder posts__item-cate-icon"></i>
                            <div class="posts__item-cate-name">
                                Tin tức
                            </div>
                        </div>
                        <div class="posts__item-cate-ad">
                            <i class="fa fa-user posts__item-cate-ad-icon"></i>
                            <div class="posts__item-cate-ad-name">
                                Việt Hoàng
                            </div>   
                        </div>
                    </div>
                    <div class="posts__item-description">
                        Nhà tại đường
                        quận........
                        huyện........
                    </div>
                </div>

                <div class="posts__item col-lg-3 col-md-6 col-sm-6">
                    <div class="posts__item-img">
                        <img src="./images/expert2.jpg">
                    </div>
                    <h3 class="posts__item-heading">
                        <a href="#" class="posts__item-title">
                            chung cư lungutng
                        </a>
                    </h3>
                    <div class="posts__item-date">
                        50m^2
                    </div>
                    <div class="posts__item-cate-wrap">
                        <div class="posts__item-cate">
                            <i class="fa fa-folder posts__item-cate-icon"></i>
                            <div class="posts__item-cate-name">
                                Tin tức
                            </div>
                        </div>
                        <div class="posts__item-cate-ad">
                            <i class="fa fa-user posts__item-cate-ad-icon"></i>
                            <div class="posts__item-cate-ad-name">
                                đức nguyễn
                            </div>   
                        </div>
                    </div>
                    <div class="posts__item-description">
                        Nhà tại đường
                        quận........
                        huyện........
                    </div>
                </div>

                <div class="posts__item col-lg-3 col-md-6 col-sm-6">
                    <div class="posts__item-img">
                        <img src="./images/product_9.png">
                    </div>
                    <h3 class="posts__item-heading">
                        <a href="" class="posts__item-title">
                            chung cư mĩ đinh II
                        </a>
                    </h3>
                    <div class="posts__item-date">
                        75m^2
                    </div>
                    <div class="posts__item-cate-wrap">
                        <div class="posts__item-cate">
                            <i class="fa fa-folder posts__item-cate-icon"></i>
                            <div class="posts__item-cate-name">
                                Tin tức
                            </div>
                        </div>
                        <div class="posts__item-cate-ad">
                            <i class="fa fa-user posts__item-cate-ad-icon"></i>
                            <div class="posts__item-cate-ad-name">
                                ngọc vân
                            </div>   
                        </div>
                    </div>
                    <div class="posts__item-description">
                        Nhà tại đường
                        quận........
                        huyện........
                    </div>
                </div>
            </article>
            <article class="row posts__view">
                <a href="" class="posts__view-btn">Xem thêm</a>
            </article>
        </div>
    </section>
    <!-- end post -->
    <!-- end post -->


    <!-- footer -->
    <footer>
        <section class="footer__top">
            <div class="container">
                <div class="row">
                    <article class="footer__top-intro col-lg-5 col-md-4 col-sm-6">
                        <h4 class="footer__top-intro-heading">
                            Về chúng tôi
                        </h4>
                        <div class="footer__top-intro-content">
                            Nhatrobalnha trụ sở tại xuanthuy-caugiay<br>
                            Chúng tôi sẽ liên tục cập nhật những ngôi nhà<br>
                            mới nhất, chất lượng nhất, hợp thời<br>
                            nhất giúp các bạn có những trải nghiệm <br>
                            tuyệt vời! <br> <br>
                            Điện thoại: 0368494*** <br>
                            Email: lus187@gmail.com <br>
                            Zalo: 036 8494 *** <br>
                        </div>
                    </article>

                    <article class="footer__top-policy col-lg-3 col-md-4 col-sm-6">
                        <h4 class="footer__top-policy-heading">
                            HỖ TRỢ KHÁCH HÀNG
                        </h4>

                        <ul class="footer__top-policy-list">
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Trung tâm trợ giúp</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">An toàn mua bán</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Quy định cần biết</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Quy chế quyền riếng tư</a>
                            </li>
                            <li class="footer__top-policy-item">
                                <a href="#" class="footer__top-policy-link">Liên hệ hỗ trợ</a>
                            </li>
                        </ul>
                    </article>

                    <article class="footer__top-contact-wrap col-lg-4 col-md-4 col-sm-6">
                        <h4 class="footer__top-contact-heading">
                            Hotline liên hệ
                        </h4>

                        <div class="footer__top-contact">
                            <div class="footer__top-contact-icon">
                                <img src="./images/phone_top.png" class="footer__top-contact-img">
                            </div>

                            <div class="footer__top-contact-phone-wrap">
                                <div class="footer__top-contact-phone">
                                    0368494***
                                </div>
                                <div class="footer__top-contact-des">
                                    (Tư vấn miễn phí 24/24)
                                </div>
                            </div>
                        </div>

                        <h4 class="footer__top-contact-heading">
                            Kết nối với chúng tôi
                        </h4>

                        <div class="footer__top-contact-social">
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="./images/facebook.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="./images/youtube.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="./images/tiktok.png">
                            </a>
                            <a href="#" class="footer__top-contact-social-link">
                                <img src="./images/zalo.png">
                            </a>
                        </div>
                    </article>
                </div>
            </div>
        </section>
        <section class="footer__bottom">
            <div class="container">
                <div class="row">
                    <span class="footer__bottom-content">@Bản quyền thuộc về nhatrobalanha</span>
                </div>
            </div>
        </section>
    </footer>

    <!-- <section class="popup__chat">
     
            <i class="fab fa-facebook-messenger" onclick="openform()"></i> 
        
        <div class="chat-popup" id="myform">
            <form action="" class="form-container">
                <h1>Chat</h1>
                <label for="msg"><b>Message</b></label>
                <textarea placeholder="Type message here.." name="msg" required></textarea>
                <button type="submit" class="btn"> Send</button>
                <button type="button" class="btn cancel" onclick="closeformn()">Close</button>
            </form>
        </div>
    </section>
    <script>
        function openform(){
    document.getElementById("myform").style.display="block";
}
function closeformn(){
    document.getElementById("myform").style.display="none";
}
   </script> -->
    <script src="{{asset('public/frontend/js/jq.js')}}"></script>

</body>

</html>