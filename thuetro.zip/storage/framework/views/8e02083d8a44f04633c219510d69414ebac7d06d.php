
<?php $__env->startSection('content_home_test'); ?>

<!-- Nhóm 1 -->

<section class="section section-collection">
    <div class="wrapper-heading-home animation-tran text-center">
        <div class="container-fluid">
            <div class="site-animation">
                <h2>
                    <a href="/collections/new-arrivals">

                        NEW ARRIVAL

                    </a>
                </h2>
            </div>
        </div>
    </div>
    <div class="wrapper-collection-1">


        <div class="container-fluid">
            <div class="row">
                <div class="clearfix content-product-list">


                    <div class="col-md-4 col-sm-6 col-xs-6 pro-loop ">











                        <div class="product-block product-resize ">
                            <div class="product-img ">



                                <a href="/products/ao-phao-1312bcm" title="Áo Phao METROPOLIS ORIGINAL 1312"
                                    class="image-resize ratiobox">
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2919_6f1eb439ea3344ab8c33d3de7af1afc9_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2919_6f1eb439ea3344ab8c33d3de7af1afc9_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2919_6f1eb439ea3344ab8c33d3de7af1afc9_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <img class="lazyload img-loop" data-sizes="auto"
                                            data-src="//product.hstatic.net/200000201725/product/_nik2919_6f1eb439ea3344ab8c33d3de7af1afc9_grande.jpg"
                                            data-lowsrc="//product.hstatic.net/200000201725/product/_nik2919_6f1eb439ea3344ab8c33d3de7af1afc9_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Phao METROPOLIS ORIGINAL 1312 " />
                                    </picture>
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2929_5ca274d1d48f4f3db86c0fcdcb8f23f2_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2929_5ca274d1d48f4f3db86c0fcdcb8f23f2_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik2929_5ca274d1d48f4f3db86c0fcdcb8f23f2_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <img class="img-loop img-hover lazyload"
                                            data-src="//product.hstatic.net/200000201725/product/_nik2929_5ca274d1d48f4f3db86c0fcdcb8f23f2_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Phao METROPOLIS ORIGINAL 1312 " />
                                    </picture>
                                </a>
                                <div class="button-add hidden">
                                    <button type="submit" title="Buy now" class="action"
                                        onclick="buy_now('1065018686')">Mua ngay<i
                                            class="fa fa-long-arrow-right"></i></button>
                                </div>
                                <div class="pro-price-mb">
                                    <span class="pro-price">995,000₫</span>

                                </div>
                            </div>
                            <div class="product-detail clearfix">
                                <div class="box-pro-detail">
                                    <h3 class="pro-name">
                                        <a href="/products/ao-phao-1312bcm" title="Áo Phao METROPOLIS ORIGINAL 1312">
                                            Áo Phao METROPOLIS ORIGINAL 1312
                                        </a>
                                    </h3>
                                    <div class="box-pro-prices">
                                        <p class="pro-price ">
                                            <span>995,000₫</span>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                    

                    
                    <div class="col-md-4 col-sm-6 col-xs-6 pro-loop ">
                        <div class="product-block product-resize ">
                            <div class="product-img ">



                                <a href="/products/ao-phao-1303bcm" title="Áo Phao approach jacket 1303"
                                    class="image-resize ratiobox">
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0792_5e498b1e88ed4266af829efc3505684b_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0792_5e498b1e88ed4266af829efc3505684b_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0792_5e498b1e88ed4266af829efc3505684b_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <img class="lazyload img-loop" data-sizes="auto"
                                            data-src="//product.hstatic.net/200000201725/product/_nik0792_5e498b1e88ed4266af829efc3505684b_grande.jpg"
                                            data-lowsrc="//product.hstatic.net/200000201725/product/_nik0792_5e498b1e88ed4266af829efc3505684b_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Phao approach jacket 1303 " />
                                    </picture>
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0788_ac16ed5837914088b54fc61ac708909f_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0788_ac16ed5837914088b54fc61ac708909f_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_nik0788_ac16ed5837914088b54fc61ac708909f_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <img class="img-loop img-hover lazyload"
                                            data-src="//product.hstatic.net/200000201725/product/_nik0788_ac16ed5837914088b54fc61ac708909f_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Phao approach jacket 1303 " />
                                    </picture>
                                </a>
                                <div class="button-add hidden">
                                    <button type="submit" title="Buy now" class="action"
                                        onclick="buy_now('1064676238')">Mua ngay<i
                                            class="fa fa-long-arrow-right"></i></button>
                                </div>
                                <div class="pro-price-mb">
                                    <span class="pro-price">850,000₫</span>

                                </div>
                            </div>
                            <div class="product-detail clearfix">
                                <div class="box-pro-detail">
                                    <h3 class="pro-name">
                                        <a href="/products/ao-phao-1303bcm" title="Áo Phao approach jacket 1303">
                                            Áo Phao approach jacket 1303
                                        </a>
                                    </h3>
                                    <div class="box-pro-prices">
                                        <p class="pro-price ">
                                            <span>850,000₫</span>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-6 pro-loop ">











                        <div class="product-block product-resize ">
                            <div class="product-img ">



                                <a href="/products/ao-ni-1298vcs" title="Áo Sweatshirt S.D to the north 1298"
                                    class="image-resize ratiobox">
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9348_817fb71119e74ee0bdd5c4cff51de1ed_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9348_817fb71119e74ee0bdd5c4cff51de1ed_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9348_817fb71119e74ee0bdd5c4cff51de1ed_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <img class="lazyload img-loop" data-sizes="auto"
                                            data-src="//product.hstatic.net/200000201725/product/_w1a9348_817fb71119e74ee0bdd5c4cff51de1ed_grande.jpg"
                                            data-lowsrc="//product.hstatic.net/200000201725/product/_w1a9348_817fb71119e74ee0bdd5c4cff51de1ed_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Sweatshirt S.D to the north 1298 " />
                                    </picture>
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9351_786a8c848d414db7a107939ed2d63026_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9351_786a8c848d414db7a107939ed2d63026_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9351_786a8c848d414db7a107939ed2d63026_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <img class="img-loop img-hover lazyload"
                                            data-src="//product.hstatic.net/200000201725/product/_w1a9351_786a8c848d414db7a107939ed2d63026_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Sweatshirt S.D to the north 1298 " />
                                    </picture>
                                </a>
                                <div class="button-add hidden">
                                    <button type="submit" title="Buy now" class="action"
                                        onclick="buy_now('1064506470')">Mua ngay<i
                                            class="fa fa-long-arrow-right"></i></button>
                                </div>
                                <div class="pro-price-mb">
                                    <span class="pro-price">385,000₫</span>

                                </div>
                            </div>
                            <div class="product-detail clearfix">
                                <div class="box-pro-detail">
                                    <h3 class="pro-name">
                                        <a href="/products/ao-ni-1298vcs" title="Áo Sweatshirt S.D to the north 1298">
                                            Áo Sweatshirt S.D to the north 1298
                                        </a>
                                    </h3>
                                    <div class="box-pro-prices">
                                        <p class="pro-price ">
                                            <span>385,000₫</span>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                    <div class="col-md-4 col-sm-6 col-xs-6 pro-loop  pro-loop-lastHide ">











                        <div class="product-block product-resize ">
                            <div class="product-img ">



                                <a href="/products/ao-ni-1297bcs" title="Áo Sweatshirt Simwood Denim black 1297"
                                    class="image-resize ratiobox">
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9322_657faa21da754b2d8de4142a7d494ba9_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9322_657faa21da754b2d8de4142a7d494ba9_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9322_657faa21da754b2d8de4142a7d494ba9_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=" />
                                        <img class="lazyload img-loop" data-sizes="auto"
                                            data-src="//product.hstatic.net/200000201725/product/_w1a9322_657faa21da754b2d8de4142a7d494ba9_grande.jpg"
                                            data-lowsrc="//product.hstatic.net/200000201725/product/_w1a9322_657faa21da754b2d8de4142a7d494ba9_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Sweatshirt Simwood Denim black 1297 " />
                                    </picture>
                                    <picture>
                                        <source media="(max-width: 480px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9328_e102b3d5fc3d4f80ae0d85854932b299_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 481px) and (max-width: 767px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9328_e102b3d5fc3d4f80ae0d85854932b299_large.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <source media="(min-width: 768px)"
                                            data-srcset="//product.hstatic.net/200000201725/product/_w1a9328_e102b3d5fc3d4f80ae0d85854932b299_grande.jpg"
                                            srcset="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=">
                                        <img class="img-loop img-hover lazyload"
                                            data-src="//product.hstatic.net/200000201725/product/_w1a9328_e102b3d5fc3d4f80ae0d85854932b299_grande.jpg"
                                            src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
                                            alt=" Áo Sweatshirt Simwood Denim black 1297 " />
                                    </picture>
                                </a>
                                <div class="button-add hidden">
                                    <button type="submit" title="Buy now" class="action"
                                        onclick="buy_now('1064506468')">Mua ngay<i
                                            class="fa fa-long-arrow-right"></i></button>
                                </div>
                                <div class="pro-price-mb">
                                    <span class="pro-price">385,000₫</span>

                                </div>
                            </div>
                            <div class="product-detail clearfix">
                                <div class="box-pro-detail">
                                    <h3 class="pro-name">
                                        <a href="/products/ao-ni-1297bcs"
                                            title="Áo Sweatshirt Simwood Denim black 1297">
                                            Áo Sweatshirt Simwood Denim black 1297
                                        </a>
                                    </h3>
                                    <div class="box-pro-prices">
                                        <p class="pro-price ">
                                            <span>385,000₫</span>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>



                    </div>

                </div>
            </div>
        </div>


    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/pages/lamtest.blade.php ENDPATH**/ ?>