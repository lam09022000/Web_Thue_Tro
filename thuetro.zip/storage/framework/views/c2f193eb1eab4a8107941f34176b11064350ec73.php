
<?php $__env->startSection('content_owner'); ?>
<section class="wrapper">
    <div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
                <section class="panel">
                    <header class="panel-heading">
                        Chỉnh sửa bài viết phòng cho thuê
                    </header>
                    <div class="panel-body">
                        <div class="position-center">
                            <form role="form" action="<?php echo e(URL::to('user/update-post')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    Tiêu đề<input type="text" class="form-control" id="" name="post_title"
                                        placeholder="Tên tiêu đề">
                                </div>
                                <div class="form-group">
                                    Miêu Tả<input type="text" class="form-control" id="" name="post_content"
                                        placeholder="Mô Tả về Loại Phòng">
                                </div>
                                <div class="form-group">
                                    Diện tích<input type="text" class="form-control" id="" name="post_s"
                                        placeholder="Mô Tả về Loại Phòng">
                                </div>
                                <div class="form-group">
                                    Mức giá<input type="text" class="form-control" id="" name="price"
                                        placeholder="Tên tiêu đề">
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <select class="form-control m-bot15" name="post_area">
                                        <?php $__currentLoopData = $area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $area_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($area_pro->area_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-6">
                                        <select class="form-control m-bot15" name="post_category">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($cate_pro->category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        
                                    </div>
                                </div>
                                <div class="form-group">
                                    Địa chỉ chính xác<input type="text" class="form-control" id="" name="post_address"
                                        placeholder="Địa chỉ">
                                </div>
                                

                                <label class="col-sm-3 control-label col-lg-3" for="inputSuccess">Tiện ích</label>
                                <div class="col-lg-6">
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u1" value="1">
                                            Phòng tắm
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u2" value="1">
                                            Phòng bếp
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u3" value="1">
                                            Wifi
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u4" value="1">
                                            TV
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u5" value="1">
                                            Tủ lạnh
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u6" value="1">
                                            Bình Nóng lạnh
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u7" value="1">
                                            Điều hòa
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u8" value="1">
                                            Nơi để xe
                                        </label>
                                    </div>
                                    <div class="checkbox">
                                        <label>
                                            <input type="checkbox" name="u9" value="1">
                                            Thời gian tự do
                                        </label>
                                    </div>

                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="u10" id="optionsRadios1" value="1"
                                                checked="">
                                            Chung chủ
                                        </label>
                                    </div>
                                    <div class="radio">
                                        <label>
                                            <input type="radio" name="u10" id="optionsRadios2"
                                                value="1">
                                            Không chung chủ
                                    </div>


                                </div>
                                
                            
                            <div class="form-group">
                                <div class="col-lg-6">
                                <input type="file" name="image1" class="form-control" 
                                 placeholder='.png/jpg' >
                                 <label></label>
                                </div>
                                <div class="col-lg-6">
                                <input type="file" name="image2" class="form-control" 
                                 placeholder='.png/jpg' >
                                 <label></label>
                                </div>
                                <div class="col-lg-6">
                                <input type="file" name="image3" class="form-control" 
                                 placeholder='.png/jpg' >
                                 <label></label>
                                </div>
                            </div>
                            
                                <button type="submit" class="btn btn-info">Thêm</button>
                            
                            </form>
                        </div>

                    </div>
                </section>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('owner.owner_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/owner/edit_post.blade.php ENDPATH**/ ?>