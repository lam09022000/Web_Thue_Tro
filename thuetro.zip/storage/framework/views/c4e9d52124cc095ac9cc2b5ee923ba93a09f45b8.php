
<?php $__env->startSection('content_admin'); ?>
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="wrapper">
		<div class="table-agile-info">
    <?php
            $message = Session::get('message') ;
            if($message){
                echo $message ;
                Session::put('message',null) ;
            }
            ?>
 <div class="panel panel-default">
    <div class="panel-heading">
     Tất cả tài khoản
    </div>
    <div>
      <table class="table" ui-jq="footable" ui-options='{
        "paging": {
          "enabled": true
        },
        "filtering": {
          "enabled": true
        },
        "sorting": {
          "enabled": true
        }}'>
        <thead>
          <tr>
            <th data-breakpoints="xs">ID</th>
            <th>Tên người dùng</th>
            <th>Email</th>
            <th>SĐT </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $all_ac; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ac_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($ac_pro->user_id); ?></td>
            <td><?php echo e($ac_pro->user_name); ?></td>
            <td><?php echo e($ac_pro->user_email); ?></td>
            <td><?php echo e($ac_pro->user_phone); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    <footer class="panel-footer">
      <div class="row">
        
        <div class="col-sm-5 text-center">
          <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
        </div>
        <div class="col-sm-7 text-right text-center-xs">                
          <ul class="pagination pagination-sm m-t-none m-b-none">
            <li><a href=""><i class="fa fa-chevron-left"></i></a></li>
            <li><a href="">1</a></li>
            <li><a href="">2</a></li>
            <li><a href="">3</a></li>
            <li><a href="">4</a></li>
            <li><a href=""><i class="fa fa-chevron-right"></i></a></li>
          </ul>
        </div>
      </div>
    </footer>
  </div>
</div>
</section>
            </div></div></div></section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/pages/v_ac_owner.blade.php ENDPATH**/ ?>