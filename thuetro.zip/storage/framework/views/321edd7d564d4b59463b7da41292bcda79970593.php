
<?php $__env->startSection('content_admin'); ?>
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="panel">
                        <header class="panel-heading">
                           Chỉnh sửa Khu Vực
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                            <?php $__currentLoopData = $edit_area; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form role="form" action="<?php echo e(URL::to('admin/update-area/'.$edit_pro->area_id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input type="text" class="form-control" value="<?php echo e($edit_pro->area_name); ?>" id="" name="area_name" placeholder="Tên Khu Vực">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" rows="8" value="<?php echo e($edit_pro->area_desc); ?>" id="" name="area_desc" placeholder="Mô Tả về Khu Vực">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-info">Sửa</button>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </section>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/pages/edit_area.blade.php ENDPATH**/ ?>