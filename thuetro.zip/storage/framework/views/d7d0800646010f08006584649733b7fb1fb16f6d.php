
<?php $__env->startSection('content_admin'); ?>
<section class="wrapper">
	<div class="form-w3layouts">
        <!-- page start-->
        <!-- page start-->
        <div class="row">
            <div class="col-lg-12">
<section class="panel">
                        <header class="panel-heading">
                           Chỉnh sửa loại phòng
                        </header>
                        <div class="panel-body">
                            <div class="position-center">
                            <?php $__currentLoopData = $edit_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <form role="form" action="<?php echo e(URL::to('admin/update-category/'.$edit_pro->category_id)); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input type="text" class="form-control" value="<?php echo e($edit_pro->category_name); ?>" id="" name="category_name" placeholder="Tên Loại phòng">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" rows="8" value="<?php echo e($edit_pro->category_desc); ?>" id="" name="category_desc" placeholder="Mô Tả về phòng">
                                </div>
                                <div class="checkbox">
                                    <label>
                                        <input type="checkbox"> Check me out
                                    </label>
                                </div>
                                <button type="submit" class="btn btn-info">Sửa</button>
                            </form>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </section>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/pages/edit_category.blade.php ENDPATH**/ ?>