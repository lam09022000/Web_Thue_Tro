<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo e($post->post_title); ?></title>
  <script src="<?php echo e(asset('public/frontend/js/jquery-3.3.1.js')); ?>"></script>
  <script src="<?php echo e(asset('public/frontend/js/bootstrap.min.js')); ?>"></script>
  <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/bootstrap.min.css')); ?>">
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('public/frontend/fonts/fontawesome/css/all.min.css')); ?>">
  <link rel="stylesheet" href="fonts/fontawesome/css/all.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <link href="https://fonts.googleapis.com/css2?family=Paytone+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('public/frontend/css/product.css')); ?>">
  <style>
    .comment{
      border-radius: 2px;
      background-color: rgb(238, 238, 238);
    }
  </style>
</head>

<body>
  <div class="app">
    <header id="header">
      <!-- header top -->
      <div class="header__top">
        <div class="container">
          <section class="row flex">
            <div class="col-lg-5 col-md-0 col-sm-0 heade__top-left">
              <span>Nhà Trọ BaLaNha</span>
            </div>

            <nav class="col-lg-7 col-md-0 col-sm-0 header__top-right">
              <ul class="header__top-list">
                <li class="header__top-item">
                  <?php
                                        $name = Session::get('user_name');
                                        $id = Session::get('user_id');
                                        echo " <a href=\"http://localhost/thuetro/user/$id\" class=\"header__top-link\"> $name</a>  ";
                                    ?>
                </li>

                <li class="header__top-item">
                  <a href="<?php echo e(URL::to('/user/manage')); ?>" class="header__top-link">
                    <?php
                                        $type = Session::get('user_type') ;
                                        if($type == 1){
                                        echo " <a href=\"http://localhost/thuetro/user/manager/$id\" class=\"header__top-link\">Quản lý</a>  ";
                                        }else{
                                            if($type == null) echo "<a href=\"http://localhost/thuetro/user/registration\" class=\"header__top-link\">Đăng kí</a> " ;
                                            else

                                            echo " <a href=\"http://localhost/thuetro/user/registration-owner/$id\" class=\"header__top-link\">Đăng kí chủ trọ</a>  ";
                                        }
                                    ?>
                  </a>
                </li>

                <li class="header__top-item">
                  <a href="<?php echo e(URL::to('user/login')); ?>" class="header__top-link">
                    <?php
                                    $id = Session::get('user_id');
                                    if($id != null){
                                        echo "Đăng xuất" ;
                                    }
                                    else {
                                        echo "Đăng nhập" ;
                                    }

                                    ?>
                  </a>
                </li>
              </ul>
            </nav>
          </section>
        </div>
      </div>
      <!--end header top -->

      <!-- header bottom -->
      <div class="header__bottom">
        <div class="container">
          <section class="row">
            <div class="col-lg-3 col-md-4 col-sm-12 header__logo">
              <h1 class="header__heading">
                <a href="#" class="header__logo-link">
                  <img src="../public/frontend/images/logo.png" alt="Logo" class="header__logo-img">
                </a>
              </h1>
            </div>

            <div class="col-lg-6 col-md-7 col-sm-0 header__search">
              <!--<select name="" id="" class="header__search-select">
                            <option value="0">All</option>
                            <option value="1">Mũ bảo hiểm</option>
                            <option value="2">Găng tay</option>
                            <option value="3">Áo phượt</option>
                            <option value="4">Giày phượt</option>
                            <option value="5">Balo phượt</option>
                        </select>  -->
              <input type="text" class="header__search-input" placeholder="Tìm kiếm tại đây...">
              <button class="header__search-btn">
                <div class="header__search-icon-wrap">
                  <i class="fas fa-search header__search-icon"></i>
                </div>
              </button>
            </div>

            <div class="col-lg-2 col-md-0 col-sm-0 header__call">
              <div class="header__call-icon-wrap">
                <i class="fas fa-phone-alt header__call-icon"></i>
              </div>
            </div>
          </section>
        </div>
      </div>
      <!--end header bottom -->

      <!-- header nav -->
      <div class="header__nav">
        <div class="container">
          <section class="row">
            <div class="header__nav col-lg-9 col-md-0 col-sm-0">
              <ul class="header__nav-list">
                <li class="header__nav-item">
                  <a href="<?php echo e(URL::to('/trang-chu')); ?>" class="header__nav-link">Trang chủ</a>
                </li>
                <li class="header__nav-item">
                  <a href="<?php echo e(URL::to('/group-post/2')); ?>" class="header__nav-link">Bài viết</a>
                </li>
                <li class="header__nav-item">
                  <a href="#" class="header__nav-link">Tuyển cộng tác viên</a>
                </li>
                <li class="header__nav-item">
                  <a href="contact.html" class="header__nav-link">Liên hệ</a>
                </li>
              </ul>
            </div>
          </section>
        </div>
      </div>
    </header>
    <!--end header nav -->

    <!-- product -->
    <section class="product">
      <div class="container">
        <div class="row bg-white pt-4 pb-4 border-bt pc">
          <!-- bài viết -->
          <article class="product__main col-lg-9 col-md-12 col-sm-12">
            <div class="row">
              <div class="product__main-img col-lg-4 col-md-4 col-sm-12">
                <div class="product__main-img-primary">
                <?php
                        echo "<img src=\"../public/frontend/images/post/{$post->picture}\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
                </div>

                <div class="product__main-img-list">
                <?php
                        echo "<img src=\"../public/frontend/images/post/{$post->picture1}\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
                  <?php
                        echo "<img src=\"../public/frontend/images/post/{$post->picture2}\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
                </div>
              </div>

              <div class="product__main-info col-lg-8 col-md-8 col-sm-12">
                <div class="product__main-info-breadcrumb">
                  Trang chủ / Sản phẩm
                </div>
                <a href="#" class="product__main-info-title">
                  <h2 class="product__main-info-heading">
                    <?php echo e($post->post_title); ?>

                  </h2>
                </a>

                <div class="product__main-info-rate-wrap">
                  <i class="fas fa-star product__main-info-rate"></i>
                  <i class="fas fa-star product__main-info-rate"></i>
                  <i class="fas fa-star product__main-info-rate"></i>
                  <i class="fas fa-star product__main-info-rate"></i>
                  <i class="fas fa-star product__main-info-rate"></i>
                </div>

                <div class="product__main-info-price">
                  <span class="product__main-info-price-current">
                    <?php echo e($post->price); ?>

                  </span>
                </div>
                <div class="product__main-info-price">
                  <span class="product__main-info-price-current">
                    <?php echo e($post->area_name); ?>

                  </span>
                </div>
                <button id="likebt" onclick="likepost()"><i class="far fa-heart"></i></button><?php echo e($post->post_like); ?>


                <div class="product__main-info-description">
                  TIỆN ÍCH:<br>
                  + Giờ giấc tự do, bạn bè đến chơi thoải mái<br>
                  + Có nhân viên vệ sinh khu vực chung<br>
                  + Có nhân viên bảo trì điện, nước khi cần<br>
                  + Đậu xe trong nhà miễn phí<br>
                  + Trang bị HỆ THỐNG VÂN TAY cực kỳ an toàn, đảm bảo an ninh<br>
                  + Được nấu ăn trong phòng </div>



                <div class="product__main-info-contact">
                  <a href="https://www.facebook.com/laml.xuanx" class="product__main-info-contact-fb">
                    <i class="fab fa-facebook-f"></i>
                    Chat Facebook
                  </a>
                  <div class="product__main-info-contact-phone-wrap">
                    <div class="product__main-info-contact-phone-icon">
                      <i class="fas fa-phone-alt "></i>
                    </div>

                    <div class="product__main-info-contact-phone">
                      <div class="product__main-info-contact-phone-title">
                        Gọi điện tư vấn
                      </div>
                      <div class="product__main-info-contact-phone-number">
                        ( 0368.494.***)
                      </div>
                    </div>

                  </div>

                </div>
              </div>
            </div>

            <div class="row bg-white">
              <div class="col-12 product__main-tab">
                <a href="#" class="product__main-tab-link product__main-tab-link--active">
                  Mô tả
                </a>
                <a href="#" class="product__main-tab-link">
                  Đánh giá
                </a>
              </div>

              <div class="col-12 product__main-content-wrap">
                <h2 class="product__main-content-heading">
                  <?php echo e($post->post_title); ?>

                </h2>

                <p>
                  <span>Nhà Trọ</span> <?php echo e($post->category_name); ?>

                </p>

                <p>
                  <span>Giá:</span> <?php echo e($post->price); ?>

                </p>

                <p>
                  <span>Ngày đăng:</span><?php echo e($post->created_at); ?>

                </p>
                <p>
                  <span>Diện tich sử dụng:</span> <?php echo e($post->post_s); ?>

                </p>
                <p>
                  <span>Địa chỉ:</span> <?php echo e($post->area_name); ?>

                </p>

                <h3>
                  Mô tả chi tiết
                </h3>
                <p>
                  <?php echo e($post->post_content); ?>

                </p>
                <p>
                  Nhà đẹp <br>
                  Bảo hành uy tín. <br>
                  Giá cả hợp lý <br>
                  Không chung chủ <br>
                </p>

                <p>
                  Với kinh nghiệm lâu năm trong nghề, <span>Nhà Trọ BaLaNha</span> tự tin mang đến cho bạn những dịch vụ
                  tốt nhất.
                </p>
                <h3>
                  Thông tin người đăng 
                </h3>
                <p>
                  <?php echo e($user->user_name); ?><br>
                  SĐT : <?php echo e($user->user_phone); ?>  <br>
                  Email : <?php echo e($user->user_email); ?> 
                </p>
                <p>
                <a href="<?php echo e(URL::to('/user/'.$user->user_id)); ?>" class="posts__view-btn">Xem thêm</a>
                </p>
                            
                <h3>
                 Bình luận 
                </h3>
                <?php $__currentLoopData = $all_cmt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p class="comment">
                  <?php echo e($cmt->user_name); ?> <br> <?php echo e($cmt->content); ?>

                </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
            </div>
          </article>
          
          <!--hết bài viết-->
        </div>
        <!--bình luận -->
       
        <section class="product__love col-12 mt-12">
          <div class="row bg-white" id="prodtuct__loving">
            <div class="col-lg-12 col-md-12 col-sm-12 product__love-title">
              <h2 class="product__love-heading">
                Viết bình luận 
              </h2>
            </div>
          </div>
          <div class="row" id="product__loving" >
              <div class="contai">
            <form action="<?php echo e(URL::to('/comment/'.$post->post_id)); ?>" method="POST" role="form" class="product__in">
            
              <input  type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"  >
              </div>
          <div>
                <textarea  class="from-control" name="cmt_content" rows="5" width="100%" ></textarea>
                                  </div>
              <button type="submit" class="btn btn-primary">Gửi</button>
                                  
                                  </form>
                                  
          </div>
        </section>

        <!-- hết bình luận -->
        
        <!--sản phẩm tương tự-->
        <section class="product__love col-12 mt-4">
          <div class="row bg-white">
            <div class="col-lg-12 col-md-12 col-sm-12 product__love-title">
              <h2 class="product__love-heading">
                Sản phẩm tương tự
              </h2>
            </div>
          </div>
          <div class="row bg-white">
            <?php $__currentLoopData = $post_same; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product__panel-item col-lg-2 col-md-3 col-sm-6">
              <div class="product__panel-img-wrap">
              <?php
                        echo "<img src=\"../public/frontend/images/post/{$post->picture}\" alt=\"Hình ảnh\" class=\"product__panel-img\">"
                        ?>
              </div>
              <h3 class="product__panel-heading">
                <a href="<?php echo e(URL::to('/apartment/'.$post->post_id)); ?>" class="product__panel-link"><?php echo e($post->post_title); ?></a>
              </h3>

              <div class="product__panel-rate-wrap">
                <i class="fas fa-star product__panel-rate"></i>
                <i class="fas fa-star product__panel-rate"></i>
                <i class="fas fa-star product__panel-rate"></i>
                <i class="fas fa-star product__panel-rate"></i>
                <i class="fas fa-star product__panel-rate"></i>
              </div>

              <div class="product__panel-price">
                <span class="product__panel-price-current">
                  <?php echo e($post->price); ?>

                </span>
              </div>
             </div>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </section>
        <!--kết thúc sản phẩm tương tự-->
      </div>
    </section>
    <!--product -->

    <!-- footer -->
    <footer>
      <section class="footer__top">
        <div class="container">
          <div class="row">
            <article class="footer__top-intro col-lg-5 col-md-4 col-sm-6">
              <h4 class="footer__top-intro-heading">
                Về chúng tôi
              </h4>
              <div class="footer__top-intro-content">
                Nhatrobalnha trụ sở tại xuanthuy-caugiay<br>
                Chúng tôi sẽ liên tục cập nhật những ngôi nhà<br>
                mới nhất, chất lượng nhất, hợp thời<br>
                nhất giúp các bạn có những trải nghiệm <br>
                tuyệt vời! <br> <br>
                Điện thoại: 0368494*** <br>
                Email: lus187@gmail.com <br>
                Zalo: 036 8494 *** <br>
              </div>
            </article>

            <article class="footer__top-policy col-lg-3 col-md-4 col-sm-6">
              <h4 class="footer__top-policy-heading">
                HỖ TRỢ KHÁCH HÀNG
              </h4>

              <ul class="footer__top-policy-list">
                <li class="footer__top-policy-item">
                  <a href="#" class="footer__top-policy-link">Trung tâm trợ giúp</a>
                </li>
                <li class="footer__top-policy-item">
                  <a href="#" class="footer__top-policy-link">An toàn mua bán</a>
                </li>
                <li class="footer__top-policy-item">
                  <a href="#" class="footer__top-policy-link">Quy định cần biết</a>
                </li>
                <li class="footer__top-policy-item">
                  <a href="#" class="footer__top-policy-link">Quy chế quyền riếng tư</a>
                </li>
                <li class="footer__top-policy-item">
                  <a href="#" class="footer__top-policy-link">Liên hệ hỗ trợ</a>
                </li>
              </ul>
            </article>

            <article class="footer__top-contact-wrap col-lg-4 col-md-4 col-sm-6">
              <h4 class="footer__top-contact-heading">
                Hotline liên hệ
              </h4>

              <div class="footer__top-contact">
                <div class="footer__top-contact-icon">
                  <img src="../public/frontend/images/phone_top.png" class="footer__top-contact-img">
                </div>

                <div class="footer__top-contact-phone-wrap">
                  <div class="footer__top-contact-phone">
                    0368494***
                  </div>
                  <div class="footer__top-contact-des">
                    (Tư vấn miễn phí 24/24)
                  </div>
                </div>
              </div>

              <h4 class="footer__top-contact-heading">
                Kết nối với chúng tôi
              </h4>

              <div class="footer__top-contact-social">
                <a href="#" class="footer__top-contact-social-link">
                  <img src="../public/frontend/images/facebook.png">
                </a>
                <a href="#" class="footer__top-contact-social-link">
                  <img src="../public/frontend/images/youtube.png">
                </a>
                <a href="#" class="footer__top-contact-social-link">
                  <img src="../public/frontend/images/tiktok.png">
                </a>
                <a href="#" class="footer__top-contact-social-link">
                  <img src="../public/frontend/images/zalo.png">
                </a>
              </div>
            </article>
          </div>
        </div>
      </section>
      <section class="footer__bottom">
        <div class="container">
          <div class="row">
            <span class="footer__bottom-content">@Bản quyền thuộc về nhatrobalanha</span>
          </div>
        </div>
      </section>
    </footer>
    <!-- end footer -->

    <script src="<?php echo e(asset('public/frontend/js/jq.js')); ?>"></script>
    <script>
    var like = document.getElementById("likebt") ;
    function likepost(){
      <?php
      //kết nối csdl 
      //tăng thêm hoặc bớt lượt thích
      //đóng cơ sở dữ liệu
      ?>
        like.outerHTML = "<button id=\"likebt\" onclick=\"likepost()\"><i class=\"fa fa-heart\"></i></button><?php echo e($post->post_like); ?>";
    }
</script>

</body>

</html><?php /**PATH C:\xampp\htdocs\thuetro\resources\views/apartment_rental.blade.php ENDPATH**/ ?>