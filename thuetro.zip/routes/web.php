<?php 

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\CategoryRoom;
use App\Http\Controllers\AreaController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TenantController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class, 'index']);                              //lấy trang chủ

Route::get('/trang-chu', [HomeController::class, 'index']);                     //lấy trang chủ
Route::get('/information',[HomeController::class , 'infor']);                   //lấy trang thông tin người dùng
Route::get('/apartment/{post_id}',[HomeController::class,'apartment']) ;
Route::post('/comment/{post_id}',[HomeController::class,'comment']) ;

Route::get('/group-post/{group_type}',[HomeController::class,'group_post_by_type'] )->where(['group_type' => '[0-9]+']) ;
Route::get('/group-post/{area_name}',[HomeController::class,'group_post_by_name'] ) ;
Route::get('/group-post/{price}',[HomeController::class,'group_post'] ) ;



Route::get('/admin', [AdminController::class, 'index']);                        //lấy quản lý admin
Route::get('/login', [AdminController::class, 'login']);                        //lấy trang đăng nhập
Route::get('/logout', [AdminController::class, 'logout']);                      //lấy trang đăng nhập
Route::get('/registration', [AdminController::class, 'registration']);          //lấy trang đăng kí
Route::post('/admin-dashboard', [AdminController::class, 'check_login']);         //kiểm tra đăng nhập
Route::post('/admin-registration', [AdminController::class, 'check_registration']);      //kiểm tra đăng kí
Route::get('/admin/acc-owner', [AdminController::class, 'acc_owner']);      //kiểm tra đăng kí
Route::get('/admin/acc-tt', [AdminController::class, 'acc_tt']);


//category_room
Route::get('/admin/add-category', [CategoryRoom::class, 'add_category']);
Route::post('admin/save-category',[CategoryRoom::class,'save_category']);                      //category
Route::get('/admin/all-category-room', [CategoryRoom::class, 'all_category']);                             //all
Route::get('/admin/edit-category-room/{category_id}', [CategoryRoom::class, 'edit_category']);    //edit
Route::post('/admin/update-category/{category_id}', [CategoryRoom::class, 'update_category']);    //update
Route::get('/admin/delete-category-room/{category_id}', [CategoryRoom::class, 'delete_category']);            //delete
 
//Area
Route::get('/admin/add-area', [AreaController::class, 'add_area']);                    //Area
Route::post('admin/save-area',[AreaController::class,'save_area']);                      //
Route::get('/admin/all-area', [AreaController::class, 'all_area']);                             //all
Route::get('/admin/edit-area/{area_id}', [AreaController::class, 'edit_area']);    //edit
Route::post('/admin/update-area/{area_id}', [AreaController::class, 'update_area']);    //update
Route::get('/admin/delete-area/{area_id}', [AreaController::class, 'delete_area']);            //delete
 
//room
Route::get('/admin/add-post', [PostController::class, 'add_post']);     
Route::get('/admin/wait-post', [PostController::class, 'wait_post']); 
Route::get('/admin/my-post', [PostController::class, 'my_post']);                      //Room
Route::post('admin/save-post',[PostController::class,'save_post']);  
Route::get('admin/allow-post/{post_id}',[PostController::class,'allow_post']);                    //
Route::get('/admin/all-post', [PostController::class, 'all_post']);                             //all
Route::get('/admin/edit-post/{post_id}', [PostController::class, 'edit_post']);    //edit
Route::post('/admin/update-post/{post_id}', [PostController::class, 'update_post']);    //update
Route::get('/admin/delete-post/{post_id}', [PostController::class, 'delete_post']);            //delete
 

//User


Route::get('/user/{user_id}', [UserController::class, 'infor'])->where(['user_id' => '[0-9]+']);                        //lấy quản lý User
Route::get('/user/registration-owner/{user_id}', [UserController::class, 'owner_registration']);          //lấy trang đăng kí
Route::get('/user/login', [UserController::class, 'acc_login']);                        //lấy trang đăng nhập
Route::get('/user/logout', [UserController::class, 'acc_logout']);                      //lấy trang đăng nhập
Route::get('/user/registration', [UserController::class, 'acc_registration']);          //lấy trang đăng kí
Route::post('/user/check-login', [UserController::class, 'check_login']);         //kiểm tra đăng nhập
Route::post('/user/account-registration', [UserController::class, 'check_registration']);      //kiểm tra đăng kí

//Owner
Route::get('/user/manager/{user_id}', [UserController::class, 'index'])->where(['user_id' => '[0-9]+']);                          //lấy trang quản lý dành cho chủ trọ
Route::get('/user/my-post', [UserController::class, 'my_post']);
Route::get('/user/add-post', [UserController::class, 'add_post']);   
Route::post('/user/save-post',[UserController::class,'save_post']);                      //lấy trang đăng nhập
Route::get('/user/wait-post', [UserController::class, 'wait_post']);                      //lấy trang đăng nhập
Route::get('/user/edit-post/{post_id}', [UserController::class, 'edit_post']);           //edit
Route::post('/user/update-post/', [UserController::class, 'update_post']);               //update
Route::get('/user/delete-post/', [UserController::class, 'delete_post']);                      //delete
 



